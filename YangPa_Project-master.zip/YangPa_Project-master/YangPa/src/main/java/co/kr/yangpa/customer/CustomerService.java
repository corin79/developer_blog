package co.kr.yangpa.customer;

import java.util.List;

public interface CustomerService {

	public List<CustomerDTO> customerService();

}
