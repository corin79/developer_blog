package co.kr.yangpa.find;


public class FindDTO {
		
		private String find_name;
		private String find_email;
		private String find_id2;
		private String find_name2;
		private String find_email2;
		
		public String getFind_name() {
			return find_name;
		}
		public void setFind_name(String find_name) {
			this.find_name = find_name;
		}
		public String getFind_email() {
			return find_email;
		}
		public void setFind_email(String find_email) {
			this.find_email = find_email;
		}
		public String getFind_id2() {
			return find_id2;
		}
		public void setFind_id2(String find_id2) {
			this.find_id2 = find_id2;
		}
		public String getFind_name2() {
			return find_name2;
		}
		public void setFind_name2(String find_name2) {
			this.find_name2 = find_name2;
		}
		public String getFind_email2() {
			return find_email2;
		}
		public void setFind_email2(String find_email2) {
			this.find_email2 = find_email2;
		}
				
}
