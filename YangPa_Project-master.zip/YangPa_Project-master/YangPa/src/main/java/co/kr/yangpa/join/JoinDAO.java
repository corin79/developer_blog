package co.kr.yangpa.join;

public interface JoinDAO {

	public int idCheck(String id);



}//interface
