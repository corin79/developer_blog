package co.kr.yangpa.customer;

import java.util.List;

public interface CustomerDAO {

	public List<CustomerDTO> customerService();

}
