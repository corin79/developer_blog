package co.kr.yangpa.batch;

public interface BatchDAO {

	public int updateState();

}
