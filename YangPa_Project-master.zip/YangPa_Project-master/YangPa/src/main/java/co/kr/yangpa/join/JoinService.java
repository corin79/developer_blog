package co.kr.yangpa.join;

public interface JoinService {

	public int idCheck(String id);


}//interface
