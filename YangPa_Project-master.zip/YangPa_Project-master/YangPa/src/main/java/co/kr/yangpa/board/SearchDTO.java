package co.kr.yangpa.board;

public class SearchDTO {
	
	private String typeno;
	private int reqNum;
	
	public String getTypeno() {
		return typeno;
	}
	public void setTypeno(String typeno) {
		this.typeno = typeno;
	}
	public int getReqNum() {
		return reqNum;
	}
	public void setReqNum(int reqNum) {
		this.reqNum = reqNum;
	}
}
