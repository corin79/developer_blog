package co.kr.yangpa.batch;

public interface BatchService {

	public int updateState();

}
